# ScriptArmor

## Overview

ScriptArmor is a script management and security platform built as a full-stack web application. The system allows users to create, store, and share scripts while providing robust access control mechanisms including API keys, user whitelisting, and secure sharing links. The platform features a dashboard interface for managing scripts, monitoring access, and generating secure distribution methods.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Components**: Comprehensive design system built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation schemas
- **Authentication**: Context-based auth provider with protected routes

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Management**: Express sessions with PostgreSQL session store
- **API Design**: RESTful endpoints with proper error handling and request logging
- **Security**: Password hashing with scrypt, CSRF protection, and secure session configuration

### Database Layer
- **Database**: PostgreSQL with Neon serverless adapter
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Schema Design**: Relational model with proper foreign key constraints and cascading deletes
- **Migrations**: Drizzle Kit for schema management and migrations

### Core Data Models
- **Users**: Authentication and user management
- **Scripts**: Core script storage with ownership and protection flags
- **Script Keys**: API key generation with expiration and activation controls
- **Whitelist Entries**: User-based access control per script
- **Script Links**: Shareable links with different formats (raw/blob) and activation states

### Security Architecture
- **Access Control**: Multi-layered approach with script ownership, API keys, and user whitelisting
- **Session Security**: Secure session configuration with PostgreSQL storage
- **Password Security**: Cryptographically secure password hashing with salt
- **Input Validation**: Zod schemas for runtime type checking and validation
- **Authentication Flow**: Session-based authentication with proper logout handling

### Development Workflow
- **Build System**: Vite for frontend development with HMR and React plugin
- **Type Safety**: Comprehensive TypeScript configuration with strict mode
- **Code Organization**: Monorepo structure with shared schemas between client and server
- **Path Resolution**: Alias-based imports for clean module resolution

## External Dependencies

### Database Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Connect PG Simple**: PostgreSQL session store adapter for Express sessions

### UI Component Library
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **Lucide React**: Icon library providing consistent iconography

### Development Tools
- **ShadCN UI**: Pre-built component system configuration for rapid development
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind and Autoprefixer plugins

### Authentication & Security
- **Passport.js**: Authentication middleware with local strategy support
- **Crypto Module**: Node.js built-in cryptographic functions for password security

### State Management & API
- **TanStack Query**: Powerful data synchronization and caching for React
- **Wouter**: Minimalist routing library for React applications
- **React Hook Form**: Performant forms with easy validation integration