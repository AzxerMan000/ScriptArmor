import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const scripts = pgTable("scripts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  content: text("content").notNull(),
  ownerId: varchar("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  isProtected: boolean("is_protected").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const scriptKeys = pgTable("script_keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  scriptId: varchar("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  keyValue: text("key_value").notNull().unique(),
  description: text("description"),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const whitelistEntries = pgTable("whitelist_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  scriptId: varchar("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  username: text("username").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const scriptLinks = pgTable("script_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  scriptId: varchar("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  linkToken: text("link_token").notNull().unique(),
  linkType: text("link_type").notNull(), // 'raw' or 'blob'
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  scripts: many(scripts),
}));

export const scriptsRelations = relations(scripts, ({ one, many }) => ({
  owner: one(users, {
    fields: [scripts.ownerId],
    references: [users.id],
  }),
  keys: many(scriptKeys),
  whitelistEntries: many(whitelistEntries),
  links: many(scriptLinks),
}));

export const scriptKeysRelations = relations(scriptKeys, ({ one }) => ({
  script: one(scripts, {
    fields: [scriptKeys.scriptId],
    references: [scripts.id],
  }),
}));

export const whitelistEntriesRelations = relations(whitelistEntries, ({ one }) => ({
  script: one(scripts, {
    fields: [whitelistEntries.scriptId],
    references: [scripts.id],
  }),
}));

export const scriptLinksRelations = relations(scriptLinks, ({ one }) => ({
  script: one(scripts, {
    fields: [scriptLinks.scriptId],
    references: [scripts.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertScriptSchema = createInsertSchema(scripts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertScriptKeySchema = createInsertSchema(scriptKeys).omit({
  id: true,
  createdAt: true,
});

export const insertWhitelistEntrySchema = createInsertSchema(whitelistEntries).omit({
  id: true,
  createdAt: true,
});

export const insertScriptLinkSchema = createInsertSchema(scriptLinks).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Script = typeof scripts.$inferSelect;
export type InsertScript = z.infer<typeof insertScriptSchema>;
export type ScriptKey = typeof scriptKeys.$inferSelect;
export type InsertScriptKey = z.infer<typeof insertScriptKeySchema>;
export type WhitelistEntry = typeof whitelistEntries.$inferSelect;
export type InsertWhitelistEntry = z.infer<typeof insertWhitelistEntrySchema>;
export type ScriptLink = typeof scriptLinks.$inferSelect;
export type InsertScriptLink = z.infer<typeof insertScriptLinkSchema>;
