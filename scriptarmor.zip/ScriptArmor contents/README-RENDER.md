# ScriptArmor - Deploy to Render

This guide will help you deploy your ScriptArmor platform to Render.

## Prerequisites

1. A Render account (free at render.com)
2. Your ScriptArmor code in a GitHub repository
3. A PostgreSQL database (Render provides free PostgreSQL)

## Deployment Steps

### Step 1: Set up Database on Render

1. Go to render.com and sign in
2. Click "New" → "PostgreSQL"
3. Choose a name like "scriptarmor-db"
4. Select the Free plan
5. Click "Create Database"
6. Note down the connection details from the database dashboard

### Step 2: Deploy the Web Service

1. Click "New" → "Web Service"
2. Connect your GitHub repository
3. Configure the service:
   - **Name**: scriptarmor
   - **Runtime**: Node
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Plan**: Free

### Step 3: Set Environment Variables

In your Render web service dashboard, add these environment variables:

```
NODE_ENV=production
PORT=10000
DATABASE_URL=[Your PostgreSQL connection string from Step 1]
SESSION_SECRET=[Generate a random string for sessions]
```

### Step 4: Deploy

1. Click "Deploy"
2. Wait for the build to complete
3. Your ScriptArmor will be available at: `https://your-service-name.onrender.com`

## Features Available After Deployment

- User registration and authentication
- Script upload and management
- API key generation for script protection
- User whitelist management
- Raw and blob link generation
- Professional dashboard interface

## Database Setup

After deployment, your database tables will be automatically created when the app starts.

## Custom Domain (Optional)

You can add a custom domain in your Render service settings if you have one.

## Support

Your ScriptArmor platform will be fully functional on Render's free tier, providing your community with a professional Luarmor alternative!