import { 
  users, scripts, scriptKeys, whitelistEntries, scriptLinks,
  type User, type InsertUser, type Script, type InsertScript,
  type ScriptKey, type InsertScriptKey, type WhitelistEntry, 
  type InsertWhitelistEntry, type ScriptLink, type InsertScriptLink
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Script operations
  getScriptsByOwner(ownerId: string): Promise<Script[]>;
  getScriptById(id: string): Promise<Script | undefined>;
  createScript(script: InsertScript): Promise<Script>;
  updateScript(id: string, updates: Partial<InsertScript>): Promise<Script | undefined>;
  deleteScript(id: string): Promise<boolean>;

  // Script key operations
  getKeysByScript(scriptId: string): Promise<ScriptKey[]>;
  getKeyByValue(keyValue: string): Promise<ScriptKey | undefined>;
  createScriptKey(key: InsertScriptKey): Promise<ScriptKey>;
  deactivateKey(id: string): Promise<boolean>;

  // Whitelist operations
  getWhitelistByScript(scriptId: string): Promise<WhitelistEntry[]>;
  createWhitelistEntry(entry: InsertWhitelistEntry): Promise<WhitelistEntry>;
  removeWhitelistEntry(id: string): Promise<boolean>;
  isUserWhitelisted(scriptId: string, username: string): Promise<boolean>;

  // Script link operations
  getLinksByScript(scriptId: string): Promise<ScriptLink[]>;
  getLinkByToken(token: string): Promise<ScriptLink | undefined>;
  createScriptLink(link: InsertScriptLink): Promise<ScriptLink>;
  deactivateLink(id: string): Promise<boolean>;

  // Session store
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  public sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Script operations
  async getScriptsByOwner(ownerId: string): Promise<Script[]> {
    return await db.select().from(scripts)
      .where(eq(scripts.ownerId, ownerId))
      .orderBy(desc(scripts.createdAt));
  }

  async getScriptById(id: string): Promise<Script | undefined> {
    const [script] = await db.select().from(scripts).where(eq(scripts.id, id));
    return script;
  }

  async createScript(script: InsertScript): Promise<Script> {
    const [newScript] = await db.insert(scripts).values(script).returning();
    return newScript;
  }

  async updateScript(id: string, updates: Partial<InsertScript>): Promise<Script | undefined> {
    const [updatedScript] = await db.update(scripts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(scripts.id, id))
      .returning();
    return updatedScript;
  }

  async deleteScript(id: string): Promise<boolean> {
    const result = await db.delete(scripts).where(eq(scripts.id, id));
    return result.rowCount > 0;
  }

  // Script key operations
  async getKeysByScript(scriptId: string): Promise<ScriptKey[]> {
    return await db.select().from(scriptKeys)
      .where(eq(scriptKeys.scriptId, scriptId))
      .orderBy(desc(scriptKeys.createdAt));
  }

  async getKeyByValue(keyValue: string): Promise<ScriptKey | undefined> {
    const [key] = await db.select().from(scriptKeys)
      .where(and(
        eq(scriptKeys.keyValue, keyValue),
        eq(scriptKeys.isActive, true)
      ));
    return key;
  }

  async createScriptKey(key: InsertScriptKey): Promise<ScriptKey> {
    const [newKey] = await db.insert(scriptKeys).values(key).returning();
    return newKey;
  }

  async deactivateKey(id: string): Promise<boolean> {
    const result = await db.update(scriptKeys)
      .set({ isActive: false })
      .where(eq(scriptKeys.id, id));
    return result.rowCount > 0;
  }

  // Whitelist operations
  async getWhitelistByScript(scriptId: string): Promise<WhitelistEntry[]> {
    return await db.select().from(whitelistEntries)
      .where(eq(whitelistEntries.scriptId, scriptId))
      .orderBy(desc(whitelistEntries.createdAt));
  }

  async createWhitelistEntry(entry: InsertWhitelistEntry): Promise<WhitelistEntry> {
    const [newEntry] = await db.insert(whitelistEntries).values(entry).returning();
    return newEntry;
  }

  async removeWhitelistEntry(id: string): Promise<boolean> {
    const result = await db.delete(whitelistEntries).where(eq(whitelistEntries.id, id));
    return result.rowCount > 0;
  }

  async isUserWhitelisted(scriptId: string, username: string): Promise<boolean> {
    const [entry] = await db.select().from(whitelistEntries)
      .where(and(
        eq(whitelistEntries.scriptId, scriptId),
        eq(whitelistEntries.username, username)
      ));
    return !!entry;
  }

  // Script link operations
  async getLinksByScript(scriptId: string): Promise<ScriptLink[]> {
    return await db.select().from(scriptLinks)
      .where(eq(scriptLinks.scriptId, scriptId))
      .orderBy(desc(scriptLinks.createdAt));
  }

  async getLinkByToken(token: string): Promise<ScriptLink | undefined> {
    const [link] = await db.select().from(scriptLinks)
      .where(and(
        eq(scriptLinks.linkToken, token),
        eq(scriptLinks.isActive, true)
      ));
    return link;
  }

  async createScriptLink(link: InsertScriptLink): Promise<ScriptLink> {
    const [newLink] = await db.insert(scriptLinks).values(link).returning();
    return newLink;
  }

  async deactivateLink(id: string): Promise<boolean> {
    const result = await db.update(scriptLinks)
      .set({ isActive: false })
      .where(eq(scriptLinks.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
