import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertScriptSchema, insertScriptKeySchema, insertWhitelistEntrySchema,
  insertScriptLinkSchema
} from "@shared/schema";
import { randomBytes } from "crypto";

function generateKey(): string {
  return "SA_" + randomBytes(16).toString("hex");
}

function generateLinkToken(): string {
  return randomBytes(12).toString("hex");
}

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Scripts routes
  app.get("/api/scripts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const scripts = await storage.getScriptsByOwner(req.user!.id);
      res.json(scripts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scripts" });
    }
  });

  app.post("/api/scripts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const scriptData = insertScriptSchema.parse({
        ...req.body,
        ownerId: req.user!.id
      });
      
      const script = await storage.createScript(scriptData);
      res.status(201).json(script);
    } catch (error) {
      res.status(400).json({ message: "Invalid script data" });
    }
  });

  app.put("/api/scripts/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const updates = insertScriptSchema.partial().parse(req.body);
      const updatedScript = await storage.updateScript(req.params.id, updates);
      res.json(updatedScript);
    } catch (error) {
      res.status(400).json({ message: "Invalid update data" });
    }
  });

  app.delete("/api/scripts/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      await storage.deleteScript(req.params.id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Failed to delete script" });
    }
  });

  // Script keys routes
  app.get("/api/scripts/:id/keys", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const keys = await storage.getKeysByScript(req.params.id);
      res.json(keys);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch keys" });
    }
  });

  app.post("/api/scripts/:id/keys", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const keyData = insertScriptKeySchema.parse({
        ...req.body,
        scriptId: req.params.id,
        keyValue: generateKey()
      });

      const key = await storage.createScriptKey(keyData);
      res.status(201).json(key);
    } catch (error) {
      res.status(400).json({ message: "Invalid key data" });
    }
  });

  app.delete("/api/keys/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      await storage.deactivateKey(req.params.id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Failed to deactivate key" });
    }
  });

  // Whitelist routes
  app.get("/api/scripts/:id/whitelist", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const whitelist = await storage.getWhitelistByScript(req.params.id);
      res.json(whitelist);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch whitelist" });
    }
  });

  app.post("/api/scripts/:id/whitelist", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const entryData = insertWhitelistEntrySchema.parse({
        ...req.body,
        scriptId: req.params.id
      });

      const entry = await storage.createWhitelistEntry(entryData);
      res.status(201).json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid whitelist data" });
    }
  });

  app.delete("/api/whitelist/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      await storage.removeWhitelistEntry(req.params.id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Failed to remove whitelist entry" });
    }
  });

  // Script links routes
  app.get("/api/scripts/:id/links", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const links = await storage.getLinksByScript(req.params.id);
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch links" });
    }
  });

  app.post("/api/scripts/:id/links", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const script = await storage.getScriptById(req.params.id);
      if (!script || script.ownerId !== req.user!.id) {
        return res.status(404).json({ message: "Script not found" });
      }

      const linkData = insertScriptLinkSchema.parse({
        ...req.body,
        scriptId: req.params.id,
        linkToken: generateLinkToken()
      });

      const link = await storage.createScriptLink(linkData);
      res.status(201).json(link);
    } catch (error) {
      res.status(400).json({ message: "Invalid link data" });
    }
  });

  app.delete("/api/links/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      await storage.deactivateLink(req.params.id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Failed to deactivate link" });
    }
  });

  // Public script access routes
  app.get("/raw/:token", async (req, res) => {
    try {
      const link = await storage.getLinkByToken(req.params.token);
      if (!link || link.linkType !== "raw") {
        return res.status(404).json({ message: "Access Denied - Invalid or expired link" });
      }

      const script = await storage.getScriptById(link.scriptId);
      if (!script) {
        return res.status(404).json({ message: "Script not found" });
      }

      res.setHeader("Content-Type", "text/plain");
      res.send(script.content);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/blob/:token", async (req, res) => {
    try {
      const link = await storage.getLinkByToken(req.params.token);
      if (!link || link.linkType !== "blob") {
        return res.status(404).json({ message: "Access Denied - Invalid or expired link" });
      }

      const script = await storage.getScriptById(link.scriptId);
      if (!script) {
        return res.status(404).json({ message: "Script not found" });
      }

      const blob = Buffer.from(script.content).toString("base64");
      res.json({ blob });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Key verification endpoint
  app.post("/verify-key", async (req, res) => {
    try {
      const { key, scriptId } = req.body;
      
      if (!key || !scriptId) {
        return res.status(400).json({ message: "Key and script ID required" });
      }

      const keyRecord = await storage.getKeyByValue(key);
      if (!keyRecord || keyRecord.scriptId !== scriptId) {
        return res.status(403).json({ message: "Access Denied - Invalid key" });
      }

      if (keyRecord.expiresAt && new Date() > keyRecord.expiresAt) {
        return res.status(403).json({ message: "Access Denied - Key expired" });
      }

      const script = await storage.getScriptById(scriptId);
      if (!script) {
        return res.status(404).json({ message: "Script not found" });
      }

      res.json({ 
        message: "Access granted",
        script: {
          id: script.id,
          name: script.name,
          content: script.content
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const scripts = await storage.getScriptsByOwner(req.user!.id);
      const protectedScripts = scripts.filter(s => s.isProtected);
      
      let totalKeys = 0;
      let totalWhitelist = 0;
      
      for (const script of scripts) {
        const keys = await storage.getKeysByScript(script.id);
        const whitelist = await storage.getWhitelistByScript(script.id);
        totalKeys += keys.filter(k => k.isActive).length;
        totalWhitelist += whitelist.length;
      }

      res.json({
        totalScripts: scripts.length,
        protectedScripts: protectedScripts.length,
        activeKeys: totalKeys,
        whitelistedUsers: totalWhitelist
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
